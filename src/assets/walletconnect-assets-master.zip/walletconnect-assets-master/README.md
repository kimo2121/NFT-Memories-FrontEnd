# WalletConnect Assets

WalletConnect Assets (svg, png and jpg)
